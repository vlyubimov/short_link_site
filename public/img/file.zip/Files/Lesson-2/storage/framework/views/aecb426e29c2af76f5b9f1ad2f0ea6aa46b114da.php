<?php $__env->startSection('page-title'); ?>
Кабинет пользователя
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="block">
        <h1>Кабинет пользователя</h1>
        <?php if(session('status')): ?>
            <div class="success-mess">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <p>Привет, <?php echo e(Auth::user()->name); ?></p>
        <p><?php echo e(Auth::user()->email); ?></p>
    </div>

    <?php if(count($articles) > 0): ?>
        <div class="articles">
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="post">
                    <h2><?php echo e($el->title); ?></h2>
                    <p><?php echo e($el->anons); ?></p>
                    <p><b>Автор:</b> <?php echo e($el->user->name); ?></p>
                    <a href="/article/<?php echo e($el->id); ?>">Прочитать</a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/GeorgiyDudar/Downloads/www/resources/views/home.blade.php ENDPATH**/ ?>