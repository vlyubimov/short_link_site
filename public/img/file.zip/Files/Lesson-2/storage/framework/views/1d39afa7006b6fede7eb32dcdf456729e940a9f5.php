<?php $__env->startSection('page-title'); ?>
<?php echo e($article->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1><?php echo e($article->title); ?> / Статья на Blog Spot</h1>
    <a href="/" class="back-button">На главную</a>
    <div class="articles one">
        <div class="post">
            <h2><?php echo e($article->title); ?></h2>
            <p><?php echo e($article->anons); ?></p><br>
            <p><?php echo $article->text; ?></p>
            <p><b>Автор:</b> <?php echo e($article->user->name); ?></p>

            <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->id == $article->user_id): ?>
                    <br><hr>
                    <a href="/article/<?php echo e($article->id); ?>/edit">Изменить</a>
                    <?php echo Form::open(['method' => 'DELETE', 'action' => ['ArticlesController@destroy', $article->id]]); ?>

                        <?php echo e(Form::submit('Удалить', ['class' => 'delete-button'])); ?>

                    <?php echo Form::close(); ?>

                <?php endif; ?>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/GeorgiyDudar/Downloads/www/resources/views/articles/show.blade.php ENDPATH**/ ?>