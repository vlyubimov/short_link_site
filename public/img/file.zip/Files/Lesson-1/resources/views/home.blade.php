@extends('layout.main')

@section('page-title')
Кабинет пользователя
@endsection

@section('content')
<div class="block">
    <h1>Кабинет пользователя</h1>
    @if (session('status'))
        <div class="success-mess">
            {{ session('status') }}
        </div>
    @endif
    <p>Вы авторизованы</p>
</div>
@endsection
