<?php if(count($errors) > 0): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="error-mess"><?php echo e($el); ?></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="success-mess"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="error-mess"><?php echo e(session('error')); ?></div>
<?php endif; ?><?php /**PATH /Users/GeorgiyDudar/Downloads/www/resources/views/blocks/messages.blade.php ENDPATH**/ ?>