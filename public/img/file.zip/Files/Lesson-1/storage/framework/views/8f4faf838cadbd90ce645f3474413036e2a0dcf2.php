<?php $__env->startSection('page-title'); ?>
Изменение статьи
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Изменение статьи</h1>
    <a href="/" class="back-button">На главную</a>
    <?php echo Form::open(['class' => 'article-form', 'method' => 'PUT']); ?>

        <?php echo e(Form::label('title', 'Название статьи')); ?>

        <?php echo e(Form::text('title', $article->title, ['placeholder' => 'Введите название статьи'])); ?>


        <?php echo e(Form::label('anons', 'Анонс статьи')); ?>

        <?php echo e(Form::textarea('anons', $article->anons, ['placeholder' => 'Введите анонс статьи'])); ?>


        <?php echo e(Form::label('text', 'Основной текст статьи')); ?>

        <?php echo e(Form::textarea('text', $article->text, ['placeholder' => 'Введите текст статьи', 'id' => 'editor'])); ?>


        <?php echo e(Form::submit('Изменить', ['class' => 'add-button'])); ?>

    <?php echo Form::close(); ?>

    <script src="https://cdn.ckeditor.com/ckeditor5/34.0.0/classic/ckeditor.js"></script>
    <script>
        ClassicEditor.create(document.querySelector('#editor') );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/GeorgiyDudar/Downloads/www/resources/views/articles/edit.blade.php ENDPATH**/ ?>