<?php $__env->startSection('page-title'); ?>
Регистрация
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Регистрация</h1>
    <a href="/" class="back-button">На главную</a>

    <form method="POST" action="/register" class="article-form">
        <?php echo csrf_field(); ?>

        <label for="name">Имя</label>
        <input id="name" type="text" value="<?php echo e(old('name')); ?>" name="name">

        <label for="email">Email</label>
        <input id="email" type="email" value="<?php echo e(old('email')); ?>" name="email">

        <label for="password">Пароль</label>
        <input id="password" type="password" value="<?php echo e(old('passowrd')); ?>" name="password">

        <label for="password-confirm">Подтверждение пароля</label>
        <input id="password-confirm" type="password" value="<?php echo e(old('password_confirmation')); ?>" name="password_confirmation">
                            
        <input type="submit" value="Зарегистрироваться" style="width: 170px"/>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/GeorgiyDudar/Downloads/www/resources/views/auth/register.blade.php ENDPATH**/ ?>