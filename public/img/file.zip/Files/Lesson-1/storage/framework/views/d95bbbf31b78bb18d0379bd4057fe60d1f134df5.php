<?php $__env->startSection('page-title'); ?>
<?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="block">
        <h1>Про нас</h1>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Accusamus sint incidunt voluptate a? Reprehenderit, harum in? Nemo rem, repellendus, nostrum quisquam nisi consectetur doloribus omnis accusamus saepe reiciendis culpa laboriosam!</p>

        <?php if(count($params) > 0): ?>
            <ul>
                <?php $__currentLoopData = $params; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($el); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/GeorgiyDudar/Downloads/www/resources/views/static/about.blade.php ENDPATH**/ ?>