<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('page-title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
</head>
<body>
    <header class="container">
        <span class="logo">Blog Spot</span>
        <nav>
            <a href="/">Главная</a>
            <a href="/about-us">Про нас</a>

            <?php if(auth()->guard()->guest()): ?>
                <a href="/login">Войти</a>
                <a href="/register">Регистрация</a>
            <?php else: ?>
                <a href="/user"><?php echo e(Auth::user()->name); ?></a>
                <a href="/article/add">Добавить статью</a>

                <form action="/logout" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit">Выйти</button>
                </form>
            <?php endif; ?>
        </nav>
    </header>
    <main class="container">
        <?php echo $__env->make('blocks.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer>Все права защищены</footer>
</body>
</html><?php /**PATH /Users/GeorgiyDudar/Downloads/www/resources/views/layout/main.blade.php ENDPATH**/ ?>