<?php $__env->startSection('page-title'); ?>
Авторизация
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Авторизация</h1>
    <a href="/" class="back-button">На главную</a>

    <form method="POST" action="/login"  class="article-form">
        <?php echo csrf_field(); ?>

        <label for="email">Email</label>
        <input id="email" type="email" value="<?php echo e(old('email')); ?>" name="email">

        <label for="password">Пароль</label>
        <input id="password" type="password" value="<?php echo e(old('passowrd')); ?>" name="password">

        <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
        <label for="remember">Запомнить меня</label>
        
        <input type="submit" value="Войти" class="login-btn" />
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/GeorgiyDudar/Downloads/www/resources/views/auth/login.blade.php ENDPATH**/ ?>